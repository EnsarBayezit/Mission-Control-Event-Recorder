# Mission Control Telemetry Simulator

## Gereksinimler
- Processing 3.5.4
- UDP library: hypermedia.net

## Varsayılan UDP
- Hedef IP: `127.0.0.1`
- Hedef port: `5555`
- Gönderim: `10 Hz`

## Paket formatı
```text
timestamp,lat,lon,heading,speed,battery,temp,mode,network
```

Örnek:
```text
1723290000123,36.812345,34.641234,90.00,8.40,74,61.0,1,72
```

## Mode değerleri
- `0` = MANUAL
- `1` = AUTO
- `2` = RTL

## Simülatör butonları
- ENGINE START
- TEMP HIGH
- LOW BATTERY
- GPS LOSS
- NETWORK DROP
- RAPID TURN
- MODE CHANGE
- OVERSPEED
- NORMALIZE
- ROUTE ON/OFF

`GPS LOSS` sırasında simülatör paket göndermeyi tamamen keser. Böylece ana yazılımın
"3 saniye veri gelmezse GPS LOST" kuralını gerçekten zaman aşımı ile yakalaması gerekir.

## Klavye
- `SPACE`: UDP gönderimini başlat/durdur
- `N`: tüm değerleri normale döndür

## Ana yazılım için beklenen event kuralları
- Battery < 20% -> LOW BATTERY
- Temperature > 80 C -> ENGINE OVERHEAT
- Speed > 15 kn -> OVERSPEED
- 3 saniye paket gelmezse -> GPS LOST
- Network < 30% -> CONNECTION WEAK
- Heading kısa sürede 45 dereceden fazla değişirse -> RAPID TURN
- Mode değişirse -> MODE CHANGE

Not: Bir alarm koşulu ilk oluştuğunda yalnızca bir kez event kaydı oluşturulmalıdır. Alarm koşulu devam ettiği sürece aynı event tekrar kaydedilmemelidir. Koşul normale döndükten sonra yeniden oluşursa yeni bir event kaydı oluşturulmalıdır.
